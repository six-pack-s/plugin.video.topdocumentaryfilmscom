# plugin.video.topdocumentaryfilmscom
Kodi video add-on for www.topdocumentaryfilms.com

Github: https://github.com/six-pack-s/plugin.video.topdocumentaryfilmscom

For Support: http://forum.kodi.tv/showthread.php?tid=240005

Release History: https://github.com/six-pack-s/plugin.video.topdocumentaryfilmscom/releases

Current Release Zip: https://github.com/six-pack-s/plugin.video.topdocumentaryfilmscom/releases/download/0.1.0/plugin.video.topdocumentaryfilmscom.zip

0.1.1
9/27/2015
            Fixed long descriptions
            Refactored styling system added capital
            Refactored add on settings

Previous releases:

0.1.0
9/26/2015
            Quick bug / settings fix
            Added new user settings to stop loading of
                main page featured ratings and descriptions
                quick page ratings and descriptions

0.0.6
9/26/2015   Added search
            Added User Settings
            Refactored Styling
            Added featured listing rating / desc details
            Added ability to turn off featured rating / desc for faster startup
            Added user comments and reviews
            Added configurable Movie Listing line
                show or hide rating and or description
            Color, bold, italic config for
                movie name
                movie rating
                movie description
            Color, bold, italic config for
                Drill Menus

0.0.5
9/25/2015   Added null check before adding a list item
            Changed color of featured

0.0.4
9/25/2015   Fixed several issues with playback
            Added By Year
            Added Descriptions in Movie Page
            Added Color

0.0.2
9/24/2015 - Refactored code

0.0.1
9/24/2015 - Initial first beta release

